LinearHashMap Documents


Compiled using java version "1.8.0_20" on Mac OS X Yosemite with the commands javac, and java 

compile LinearProbingHashMap.java with the command
	Javac LinearProbingHashMap.java

To run the program the command is 
	java LinearProbingHashMap


LinearProbingHashMap.java contains all the code for the HashMap class and the main to run the code. 


